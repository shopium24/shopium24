
<div class="site-index">

    <div class="jumbotron">
        <h1>Welcome!</h1>

        <p class="lead">You have successfully created your <?= Yii::$app->name?> application.</p>

       {block_1}
    </div>

 {block_3}
</div>
