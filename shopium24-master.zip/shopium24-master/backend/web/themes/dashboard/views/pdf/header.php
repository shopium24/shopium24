<h1>dasdsa</h1>
<div class="container">
<div class="row">
    <div class="col-md-6">
asd
    </div>
    <div class="col-md-6">
asds
    </div>
</div>
</div>
