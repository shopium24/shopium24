<?php

return [
    'adminEmail' => 'dev@pixelion.com.ua',
    'domain'=>'shopium24.loc'
];
