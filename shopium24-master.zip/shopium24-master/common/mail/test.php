<?php
use yii\helpers\Html;
?>

    <p>Hello 123123</p>

    <p>Follow the link below to reset your password:</p>

<img src="<?= $message->embed($imageFileName); ?>" width="100">
