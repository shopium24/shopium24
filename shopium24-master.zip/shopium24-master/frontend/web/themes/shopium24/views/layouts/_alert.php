<div class="alert alert-<?= $type ?>" role="alert">
<?= $message ?>
</div>