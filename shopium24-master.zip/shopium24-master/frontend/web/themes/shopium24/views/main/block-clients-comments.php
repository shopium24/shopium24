<div class="container-fluid bg-primary">
    <div class="row">
        <div class="container block-padding">
            <div class="row text-center">
                <h3 class="text-uppercase">Отзывы наших клиентов</h3>
                <div class="col-lg-4 col-md-4 wow animated fadeInUp">
                     <div class="client-image"><img src="/uploads/ava.jpg" class="img-thumbnail img-circle" alt="" /></div>
                    <div class="client-comment text-italic">
                        BuildStore - команда профессионалов,
                        любят свою работу и знают, как её делать
                        хорошо и качественно. Постоянно
                        превосходят все
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 wow animated fadeInUp">
                    <div class="client-image"><img src="/uploads/ava.jpg" class="img-thumbnail img-circle" alt="" /></div>
                    <div class="client-comment text-italic">
                        Чёткость, надёжность, функциональность.
                        Оперативная техническая поддержка!
                        Прекрасный сервис - результат слаженной
                        работы программистов и технарей.
                        Приятно работать
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 wow animated fadeInUp">
                     <div class="client-image"><img src="/uploads/ava.jpg" class="img-thumbnail img-circle" alt="" /></div>
                    <div class="client-comment text-italic">
                        Чёткость, надёжность, функциональность.
                        Оперативная техническая поддержка!
                        Прекрасный сервис - результат слаженной
                        работы программистов и технарей.
                        Приятно работать
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>