<div class="container-fluid bg-white" name="plans">
    <div class="row">
        <div class="container block-padding">
<?php echo $this->render('/layouts/partials/_plan_table'); ?>
        </div>
    </div>
</div>

<?php //$this->renderPartial('current_theme.views.main.default.block-clients-comments'); ?>
<?php //$this->renderPartial('current_theme.views.main.default.block-demo'); ?>