<?php
$list = array(
    array(
        'name' => 'Индивидуальный дизайн',
        'price' => 'от 2.000',
        'text' => '',
    ),
    array(
        'name' => 'URL-English',
        'price' => '300',
        'text' => 'Ваши ссылки будут выглить к примеру так: в место <code>/product/moy_luchsiy_tovar</code>  <code>/product/my_best_product</code><br/> все ссылки генерируются с помощью Yandex translate<br><br>Рекомендуем подключение услуги с самого начало формирование вашего магазина, в противном случае Вам придется пересохронять все записи заного.'
    ),

);
?>

<div class="text-center">
    <h1>О магазине</h1>
</div>

<p>Магазин </p>

<div class="alert alert-info">
    Все услигу действуют на постоянной основе.
</div>