<script>location.reload();</script>
<?php
echo Yii::app()->tpl->alert('success',Yii::t('UsersModule.default', 'LOGIN_SUCCESS'));
?>
