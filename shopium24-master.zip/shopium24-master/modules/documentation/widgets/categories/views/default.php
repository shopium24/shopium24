
<div id="catalog-left-nav">
   
    <div class="test">
        <?= $this->context->recursive($result['items']); ?>
    </div>
</div>

