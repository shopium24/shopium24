<?php

return [
    'NAME' => 'Название',
    'DOMAIN' => 'Домен',
];
