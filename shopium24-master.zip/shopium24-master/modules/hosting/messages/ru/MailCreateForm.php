<?php

return [
    'MAILBOX' => 'Название почты',
    'PASSWORD' => 'Пароль',
    'ANTISPAM' => 'Антиспам',
    'TYPE' => 'Тип почтового ящика',
    'FORWARD' => 'Перенаправлять почту на почту',
    'AUTORESPONDER' => 'Включить автоответчик',
    'AUTORESPONDER_TITLE' => 'Заголовок автоответчика',
    'AUTORESPONDER_TEXT' => 'Текст письма автоответчика',
];
