<?php

return [
    'AUTH_LOGIN' => 'Логин E-mail',
    'AUTH_TOKEN' => 'Токен',
    'ACCOUNT' => 'Аккаунт',
];
