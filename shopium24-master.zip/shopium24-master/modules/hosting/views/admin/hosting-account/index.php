<?php

use panix\engine\Html;


echo Html::a('info', ['/admin/hosting/hosting-account/info'], ['class' => 'btn btn-default']);
echo Html::a('plans', ['/admin/hosting/hosting-account/plans'], ['class' => 'btn btn-default']);



