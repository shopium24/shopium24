<?php

use panix\engine\Html;

echo Html::a('info', ['info'], ['class' => 'btn btn-default']);
echo Html::a('host_create', ['host-create'], ['class' => 'btn btn-default']);



