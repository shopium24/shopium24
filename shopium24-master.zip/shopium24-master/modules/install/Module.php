<?php

namespace app\modules\install;

class Module extends \panix\engine\WebModule {

    public $routes = [
        'install' => 'install/default/index',
    ];



}
