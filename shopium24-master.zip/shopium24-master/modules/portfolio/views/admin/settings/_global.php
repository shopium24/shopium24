        <?= $form->field($model, 'per_page') ?>
    <?= $form->field($model, 'product_related_bilateral')->checkbox() ?>